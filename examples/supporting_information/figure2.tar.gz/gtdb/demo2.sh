treeprofiler annotate \
--tree bac120_r202.nw \
--input_type newick \
--metadata bac120_metadata_r202.tar.gz,progenome3.tar.gz \
--taxonomic_profile \
--taxadb GTDB \
-o ./

treeprofiler plot \
--tree bac120_r202_annotated.ete \
--input_type ete \
--barplot_layout genome_size,protein_count \
--heatmap_layout gc_percentage \
--binary_layout aquatic_habitat,host_associated,soil_habitat \
--rectangle_layout ncbi_assembly_level,ncbi_genome_category \
--taxonclade_layout \
--column_width 50

