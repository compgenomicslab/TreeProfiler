#!/bin/bash

# *Annotate multiple metadatas into tree, seperated by ,
echo "Annotate example tree with two metadata tables"
treeprofiler annotate \
--tree example.nw \
--input_type newick \
--internal_parser support \
--metadata example_metadata1.tsv,example_metadata2.tsv \
--bool_prop bool_type \
-o ./

echo "Visualize properties categorical data random_type in rectangle_layout, numerical data sample1, sample2 in heatmap_layout and barplot_layout."
treeprofiler plot \
--tree example_annotated.ete \
--input_type ete \
--rectangle_layout random_type \
--binary_layout bool_type \
--heatmap_layout sample1,sample2,sample3 \
--barplot_layout sample4,sample5 \
--profiling_layout random_type \
--column_width 40 \
--padding_x 3
